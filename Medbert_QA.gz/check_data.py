import json

with open('Data/qa_hdf_2014.csv','r',encoding='utf-8') as f:
    a = f.readlines()
print(len(a))