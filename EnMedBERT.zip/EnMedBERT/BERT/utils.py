# coding: UTF-8
import re
import time
import torch
from tqdm import tqdm
from datetime import timedelta

PAD, CLS, SEP = '[PAD]', '[CLS]', '[SEP]'  # padding符号, bert中综合信息符号


def build_dataset(config):
    def load_dataset(path, class_list, pad_size=32):
        contents = []
        with open(path, 'r', encoding='UTF-8') as f:
            for i, line in tqdm(enumerate(f)):
                # if i == 10000:
                #     break
                try:
                    line = line.strip()
                    if not line:
                        continue
                    line = line.split('\t')

                    if len(line) == 5:
                        query_1, query_2, label, question_entry, answer_entry = line
                    else:
                        query_1, query_2, label, id, question_entry, answer_entry = line

                    token_1 = config.tokenizer.tokenize(query_1)
                    token_2 = config.tokenizer.tokenize(query_2)

                    question_start = re.search(question_entry, query_1, flags=0)
                    answer_start = re.search(answer_entry, query_2, flags=0)

                    local_1 = question_start.span()[0] if question_start != None else 0
                    local_2 = answer_start.span()[0] if answer_start != None else 0

                    if question_entry == 'none':
                        local_1 = 128
                    if answer_entry == 'none':
                        local_2 = 128

                    if local_1 <= 126 and local_2 <= 125:
                        local_1 += 1
                        local_2 += 2
                    if local_1 <= 126 and local_2 > 125:
                        local_2 = 0
                    if local_1 > 125:
                        local_1 = 0
                        local_2 = 0

                    token = [CLS] + token_1 + [SEP] + token_2
                    seq_len = len(token)
                    mask = []
                    token_ids = config.tokenizer.convert_tokens_to_ids(token)

                    if pad_size:
                        if len(token) < pad_size:
                            mask = [1] * (len(token_1) + 1) + [0] * (pad_size - len(token_1) - 1)
                            token_ids += ([0] * (pad_size - len(token)))
                        else:
                            mask = [1] * pad_size
                            token_ids = token_ids[:pad_size]
                            seq_len = pad_size
                    contents.append((token_ids, int(label), seq_len, mask, [local_1, question_entry], [local_2, answer_entry], [query_1, query_2]))
                except:
                    continue
        return contents

    train = load_dataset(config.train_path, config.class_list, config.pad_size)
    dev = load_dataset(config.dev_path, config.class_list, config.pad_size)
    test = load_dataset(config.test_path, config.class_list, config.pad_size)
    return train, dev, test


class DatasetIterater(object):
    def __init__(self, batches, batch_size, device):
        self.batch_size = batch_size
        self.batches = batches
        self.n_batches = len(batches) // batch_size
        self.residue = False  # 记录batch数量是否为整数
        if len(batches) % self.n_batches != 0:
            self.residue = True
        self.index = 0
        self.device = device

    def _to_tensor(self, datas):
        x = torch.LongTensor([_[0] for _ in datas]).to(self.device)
        y = torch.LongTensor([_[1] for _ in datas]).to(self.device)

        question = [_[-3] for _ in datas]
        answer = [_[-2] for _ in datas]
        text = [_[-1] for _ in datas]

        # pad前的长度(超过pad_size的设为pad_size)
        seq_len = torch.LongTensor([_[2] for _ in datas]).to(self.device)
        mask = torch.LongTensor([_[3] for _ in datas]).to(self.device)

        return (x, seq_len, mask, question, answer), y, text

    def __next__(self):
        if self.residue and self.index == self.n_batches:
            batches = self.batches[self.index * self.batch_size: len(self.batches)]
            self.index += 1
            batches = self._to_tensor(batches)
            return batches

        elif self.index >= self.n_batches:
            self.index = 0
            raise StopIteration
        else:
            batches = self.batches[self.index * self.batch_size: (self.index + 1) * self.batch_size]
            self.index += 1
            batches = self._to_tensor(batches)
            return batches

    def __iter__(self):
        return self

    def __len__(self):
        if self.residue:
            return self.n_batches + 1
        else:
            return self.n_batches


def build_iterator(dataset, config):
    iter = DatasetIterater(dataset, config.batch_size, config.device)
    return iter


def get_time_dif(start_time):
    """获取已使用时间"""
    end_time = time.time()
    time_dif = end_time - start_time
    return timedelta(seconds=int(round(time_dif)))
