# coding: UTF-8
import torch
import torch.nn as nn
# from pytorch_pretrained_bert import BertModel, BertTokenizer
from pytorch_pretrained import BertModel, BertTokenizer

import logging
import gensim.models as word2vec
from gensim.models.word2vec import LineSentence


def load_word2vec_model():
    # load word2vec
    model = word2vec.KeyedVectors.load_word2vec_format('./medical_word_embedding.bin')
    return model


model = load_word2vec_model()
# model = 0


class Config(object):
    """配置参数"""

    def __init__(self, dataset):
        self.model_name = 'bert'

        # self.train_path = dataset + '/bert_tf_train_entity.csv'  # 训练集
        # self.dev_path = dataset + '/bert_tf_dev_entity.csv'  # 验证集
        # # self.test_path = dataset + '/bert_tf_dev_entity.csv'  # 验证集
        # self.test_path = dataset + '/new_bert_tf_test_entity.csv'  # 测试集

        self.train_path = dataset + '/bert_tf_train_entity.csv'  # 训练集
        self.dev_path = dataset + '/bert_tf_dev_entity.csv'  # 验证集
        self.test_path = dataset + '/new_bert_tf_test_entity.csv'  # 测试集

        self.class_list = [0, 1]  # 类别名单
        self.save_path = dataset + '/saved_dict/420000_9/' + self.model_name + '.ckpt'  # 模型训练结果
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')  # 设备

        self.require_improvement = 4000000  # 若超过1000batch效果还没提升，则提前结束训练
        self.num_classes = len(self.class_list)  # 类别数
        self.num_epochs = 3  # epoch数
        self.batch_size = 8  # mini-batch大小
        self.pad_size = 128  # 每句话处理成的长度(短填长切)
        self.learning_rate = 2e-5  # 学习率
        self.bert_path = './bert_pretrain'
        # self.bert_path = './RoBERTa_zh_L12_PyTorch'
        # self.bert_path = './unilm'
        self.tokenizer = BertTokenizer.from_pretrained(self.bert_path)
        self.hidden_size = 768


class Model(nn.Module):

    def __init__(self, config):
        super(Model, self).__init__()
        self.bert = BertModel.from_pretrained(config.bert_path)
        for param in self.bert.parameters():
            param.requires_grad = True
        self.fc = nn.Linear(config.hidden_size, config.num_classes)
        self.batch_size = config.batch_size
        self.embeding_model = model

    def forward(self, x):
        context = x[0]  # 输入的句子
        question = x[3]
        answer = x[4]

        entry_list = []

        for _ in range(self.batch_size):
            try:
                q_local, question_text = question[_]
                a_local, answer_text = answer[_]
            except:
                print(question)

            if q_local > 0:
                try:
                    question_embeding = model[question_text]
                except:
                    question_embeding = [0] * 768
            else:
                question_embeding = [0] * 768

            if a_local > 0:
                try:
                    answer_embeding = model[answer_text]
                except:
                    answer_embeding = [0] * 768
            else:
                answer_embeding = [0] * 768

            entry_list.append([[q_local, question_embeding], [a_local, answer_embeding]])

        mask = x[2]  # 对padding部分进行mask，和句子一个size，padding部分用0表示，如：[1, 1, 1, 1, 0, 0]
        _, pooled = self.bert(context, attention_mask=mask, output_all_encoded_layers=False, entry_list=entry_list)


        out = self.fc(pooled)
        return out

        """
        for _ in range(self.batch_size):
            q_local, question_text = question[_]
            a_local, answer_text = answer[_]
            cont = context[_]

            if q_local > 0:
                try:
                    cont[0][q_local] += model[question_text].cuda()
                except:
                    pass
            if a_local > 0:
                try:
                    cont[0][a_local] += model[answer_text].cuda()
                except:
                    continue
        """
